public class Gugu2 {
	public static void main(String[] args){
		for(int a=1; a<=9; a++){
			for(int b=1; b<=9; b++){
				int result = a*b;
				System.out.println(result);
				}
			System.out.println();
			}
		}
}
